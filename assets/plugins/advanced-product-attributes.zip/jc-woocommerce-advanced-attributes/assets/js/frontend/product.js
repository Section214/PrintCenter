jQuery(function($){

	var getAttribute = function(attr_name){

		if(jcaa_attrs === null){
			return false;
		}

		for(var i = 0; i < jcaa_attrs.length; i++){

			var attr = jcaa_attrs[i];
			if(attr.name === attr_name){
				return attr;
			}
		}

		return false;
	};

	var getAttributeOption = function(attr, option){

		for( var i = 0; i < attr.options.length; i++){

			var attr_option = attr.options[i];
			if(attr_option.value === option){
				return attr_option;
			}
		}

		return false;
	};

	var active_class = 'jcaa_active_attr';
	var disable_class = 'jcass_attr_disable';

	// generate HTML output
	$( 'select[name^="attribute_pa_"]').each(function(){

		var _select = $(this);
		var _name = $(this).attr('name').substr(10);
		var _attr = getAttribute(_name);
		
		// if attr exists in array and is not set to default output
		if(_attr !== false && _attr.type !== 'default'){

			if(_attr.label === 'hide'){
				_select.parents('tr').find('.label').css('visibility', 'hidden');
			}

			var classes = ''

			// style
			if(_attr.style === 'rounded' && _attr.type !== 'text'){
				classes += 'jcaa_rounded_corners';
			}

			// size, defaults to small
			if( _attr.size === 'large' ){
				classes += ' jcaa_size_large';
			}else if( _attr.size === 'medium' ){
				classes += ' jcaa_size_medium';
			}else{
				classes += ' jcaa_size_small';
			}

			var htmlOutput = '';

			htmlOutput += '<ul id="jcaa_attr_'+_name+'" class="jcaa_attr_select jcaa_attr_variable_select '+classes+'">';

			_select.find('option').each(function(){
				
				var _option = getAttributeOption(_attr, $(this).val());
				if(_option !== false){

					if(_attr.type === 'image'){
						htmlOutput += '<li><img src="'+_option.img+'" alt="'+_option.alt+'" title="'+_option.name+'" data-target="#'+_select.attr('id')+'" data-value="'+_option.value+'" class="jcaa_attr_option jcaa_obj_image" /></li>';	
					}else if(_attr.type === 'color'){
						htmlOutput += '<li><div style="background: '+_option.color+';" data-target="#'+_select.attr('id')+'" title="'+_option.name+'" data-value="'+_option.value+'" class="jcaa_attr_option jcaa_obj_color"></div></li>';	
					}else if(_attr.type === 'text'){
						htmlOutput += '<li><a data-target="#'+_select.attr('id')+'" data-value="'+_option.value+'" title="'+_option.name+'" class="jcaa_attr_option jcaa_obj_text">'+_option.name+'</a></li>';
					}
	
				}
			});

			htmlOutput += '</ul>';

			_select.after(htmlOutput);
			_select.hide();
		}
	});

	// process clicks
	$('.variations_form.cart .jcaa_attr_select').each(function(){

		var _attr_list = $(this);
		// var active_class = 'jcaa_active_attr';

		_attr_list.find('.jcaa_attr_option').each(function(){

			var _attr_option = $(this);
			_attr_option.click(function(event){

				// dont process it
				if($(this).hasClass(disable_class)){
					return event.preventDefault();
				}

				var _select_target = $(_attr_option.data('target'));
				var _select_value = _attr_option.data('value');

				// trigger touch
				$(_select_target).trigger('touchstart');
				
				if($(_select_target).find('option[value="'+_select_value+'"]').prop("selected") == true){

					// reset select with default choice
					$(_select_target).find('option').attr("selected", false);
					$(_select_target).find('option:first').attr("selected", true);

				}else{

					// update select with choice
					$(_select_target).find('option').attr("selected", false);
					$(_select_target).val(_select_value);
					$(_select_target).find('option[value="'+_select_value+'"]').attr("selected", true);
					
				}

				// trigger change
				$(_select_target).trigger('change');

				event.preventDefault();
			});
		});

	});

	/**
	 * Set active state for selector on select change
	 */
	$('body').on( 'change', '.variations select', function( event ) {

		var _name = $(this).attr('name').substr(10);

		$('ul#jcaa_attr_'+_name+' .' + active_class).removeClass(active_class);
		$('ul#jcaa_attr_'+_name+' [data-value="' + $(this).val() + '"]').parent().addClass(active_class);

		// disable options which are not in stock
		/*var product_variations = $('.variations_form.cart').data('product_variations');
		var active_attrs = [];
		var found = false;
		
		$('.variations select').each(function(){

			if($(this).val() !== ''){
				found = true;
			}
			active_attrs[$(this).attr('name')] = $(this).val();
			// }
		});

		if(!found){
			return false;
		}

		var matching_variations = $.fn.wc_variation_form.find_matching_variations( product_variations, active_attrs );

		$.each(matching_variations, function(index, item){

			if(item.is_in_stock === false){

				for( var attr_key in item.attributes){
					var attr_val = item.attributes[attr_key];

					//  active attribute has not been selected
					if(active_attrs[attr_key] === ''){

						var _name = attr_key.substr(10);
						var _jcaa_elem = $('#jcaa_attr_'+_name);

						if(attr_val === ''){

							// match anye attribute value
							_jcaa_elem.find('.jcaa_attr_option').addClass(disable_class);

						}else{

							// match a specific attribute value
							_jcaa_elem.find('.jcaa_attr_option[data-value="' + attr_val  + '"]').addClass(disable_class);
						}

					}
				}
			}
		});*/

	});
	
	/**
	 * Disable choices if not avaiable
	 */
	$('.variations_form').on('woocommerce_update_variation_values', function(event){
		
		$( 'select[name^="attribute_pa_"]').each(function(){

			var _select = $(this);
			var _name = $(this).attr('name').substr(10);
			var _jcaa_elem = $('#jcaa_attr_'+_name);

			_jcaa_elem.find('.jcaa_attr_option').each(function(){

				var _attr_option = $(this);
				var _select_value = _attr_option.data('value');	

				if(_select.find('option[value="'+_select_value+'"]').length == 1){
					_attr_option.removeClass(disable_class);
				}else{
					_attr_option.addClass(disable_class);
				}
			});
		});

	});
});